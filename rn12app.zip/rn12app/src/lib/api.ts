import { SearchRequest, SearchResponse } from "../types/search";
//
// const IP_ADDRESS='192.168.1.68';
// const IP_ADDRESS=process.env.LOCAL_IP_ADDRESS || 'localhost';
const IP_ADDRESS=process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS;
//
const BASE_URL = `http://${IP_ADDRESS}:3000`; // change if needed
// const BASE_URL = `http://${process.env.IP_ADDRESS}:3000`; // change if needed
// const BASE_URL = "http://192.168.137.1:3000"; // change if needed

export const fetchSearchResults = async (
  
  payload: SearchRequest
): Promise<SearchResponse> => {
  console.log("Rendering Center component 3");
  const response = await fetch(`${BASE_URL}/api/search`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(error || "Search failed");
  }

  return response.json();
};

export async function fetchCenterDetail(centerId: string) {
  console.log("fetchCenterDetail");
  const res = await fetch(
    `${BASE_URL}/center/${centerId}`
  );

  if (!res.ok) {
    throw new Error("Failed to fetch center detail");
  }

  return res.json();
}