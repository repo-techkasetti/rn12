// const IP_ADDRESS = "192.168.1.68";
const IP_ADDRESS=process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS;

const MY_BASE_URL = `http://${IP_ADDRESS}:3000`;
const BASE_URL = `${MY_BASE_URL}/api`;

type PatientInput = {
  name: string;
  gender: string;
  relation: string;
};

const getUserId = () => {
  const userId = global.userId;

  console.log("CURRENT USER ID:", userId);

  if (!userId) {
    throw new Error("User not logged in");
  }

  return userId;
};

export const getPatients = async () => {
  const userId = getUserId();

  const res = await fetch(`${BASE_URL}/patients`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      userid: userId
    }
  });

  console.log("GET /patients STATUS:", res.status);

  if (!res.ok) {
    const text = await res.text();
    console.log("PATIENT FETCH ERROR:", text);
    throw new Error("Failed to fetch patients");
  }

  return res.json();
};

export const createPatient = async (patient: PatientInput) => {
  const userId = getUserId();

  const res = await fetch(`${BASE_URL}/patients`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      userid: userId
    },
    body: JSON.stringify(patient)
  });

  console.log("POST /patients STATUS:", res.status);

  if (!res.ok) {
    const text = await res.text();
    console.log("CREATE PATIENT ERROR:", text);
    throw new Error("Failed to create patient");
  }

  return res.json();
};