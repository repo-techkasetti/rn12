  //
// const IP_ADDRESS='192.168.1.68';
const IP_ADDRESS=process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS;
//
const BASE_URL = `http://${IP_ADDRESS}:3000`; // change if needed

const API = `${BASE_URL}`; 
// const API = "http://192.168.137.1:3000"; 
// replace with your computer IP

export const createBooking = async (payload: any) => {
  const res = await fetch(`${API}/api/bookings/create`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  return res.json();
};

export const verifyPayment = async (payload: any) => {
  const res = await fetch(`${API}/api/payment/verify`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  return res.json();
};