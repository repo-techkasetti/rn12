import { router } from "expo-router";
import { Text, TouchableOpacity, View } from "react-native";

export default function Success() {
  return (
    <View style={{flex:1, justifyContent:"center", alignItems:"center"}}>
      <Text style={{fontSize:24,fontWeight:"bold"}}>
        Booking Successful 🎉
      </Text>
            <TouchableOpacity
              onPress={() => 
                router.push("/")   // ✅ CHANGE HERE
              }
              style={{
                backgroundColor: "#007AFF",
                padding: 15,
                borderRadius: 10,
              }}
            >
              <Text style={{ color: "white" }}>
                GO Home   {/* optional rename */}
              </Text>
            </TouchableOpacity>
    </View>
  );
}