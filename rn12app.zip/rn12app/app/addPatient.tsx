import { router, useLocalSearchParams } from "expo-router";
import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { createPatient } from "../src/lib/patientApi";

export default function AddPatient() {

  const params = useLocalSearchParams();

  const [name, setName] = useState("");
  const [gender, setGender] = useState("MALE");
  const [relation, setRelation] = useState("SELF");

  const handleCreatePatient = async () => {

    if (!name.trim()) {
      alert("Please enter patient name");
      return;
    }

    try {

      const patient = await createPatient({
        name,
        gender,
        relation
      });

      router.push({
        // pathname: "/review",
        pathname: "/patient",
        params: {
          ...params,
          patientId: patient.id,
          patient
        }
      });

    } catch (e) {

      console.log("Create patient error", e);

    }
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>

      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        Add Patient
      </Text>

      <TextInput
        placeholder="Patient Name"
        value={name}
        onChangeText={setName}
        style={{
          borderWidth: 1,
          padding: 10,
          marginTop: 20
        }}
      />

      <TextInput
        placeholder="Gender (MALE / FEMALE)"
        value={gender}
        onChangeText={setGender}
        style={{
          borderWidth: 1,
          padding: 10,
          marginTop: 20
        }}
      />

      <TextInput
        placeholder="Relation (SELF / FATHER / MOTHER)"
        value={relation}
        onChangeText={setRelation}
        style={{
          borderWidth: 1,
          padding: 10,
          marginTop: 20
        }}
      />

      <Pressable
        onPress={handleCreatePatient}
        style={{
          marginTop: 20,
          backgroundColor: "blue",
          padding: 12
        }}
      >
        <Text style={{ color: "white", textAlign: "center" }}>
          Save Patient
        </Text>
      </Pressable>

    </View>
  );
}