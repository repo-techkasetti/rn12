import { router } from "expo-router";
import { useState } from "react";
import {
  FlatList,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import useFetch from "../src/hooks/useFetch";
import { fetchSearchResults } from "../src/lib/api";
import { SearchResponse } from "../src/types/search";

export default function Search() {
  const [query, setQuery] = useState("");

  const {
    data,
    loading,
    error,
    refetch,
  } = useFetch<SearchResponse>(() =>
    fetchSearchResults({
      location: null,
      modality: query, // will use latest query
      test_keyword: null,
      preferred_date: null, //"2026-03-09"
      search_window_days: 14,
      sort: null,
      limit: 10,
    }),
    false
  );

  const handleSearch = () => {
    if (!query.trim()) return;
    refetch(); // manually trigger
  };

  const cards = data?.cards ?? [];

  const getSection = (sections: any[], type: string) =>
    sections.find((s) => s.type === type)?.value;
console.log("DATA:", data);
  return (
    <View style={{ flex: 1, padding: 20 }}>
      <TextInput
        value={query}
        onChangeText={setQuery}
        placeholder="Search MRI, CT..."
        style={{
          borderWidth: 1,
          padding: 10,
          borderRadius: 10,
        }}
        onSubmitEditing={handleSearch}
      />

      {loading && <Text>Loading...</Text>}
      {error && <Text>{error.message}</Text>}

      <FlatList
        data={cards}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          const title = getSection(item.sections, "TITLE")?.text;
          const subtitle = getSection(item.sections, "SUBTITLE")?.text;
          const meta = getSection(item.sections, "META")?.text;
          const rating =
            getSection(item.sections, "METRICS")?.items?.[0]?.value;
          const price = getSection(item.sections, "PRICE")?.display;
          const availability =
            getSection(item.sections, "AVAILABILITY")?.totalAvailableSlots;
          const cta =
            getSection(item.sections, "CTA")?.actions?.[0];

          if (!cta) return null;

          return (
            <TouchableOpacity
              onPress={() =>
                // router.push({
                //   pathname: "/center",
                //   params: {
                //     centerId: cta.payload.center_id,
                //     modalityId: cta.payload.modality_id,
                //     testConfigId: cta.payload.test_config_id,
                //   },
                // }); 
                //
                router.push({
                  pathname: "/center",
                  params: {
                    centerId: cta.payload.center_id,
                    modalityId: cta.payload.modality_id,
                    testConfigId: cta.payload.test_config_id,
                  },
                               
                //
                })
              }
              style={{
                padding: 15,
                borderWidth: 1,
                borderRadius: 12,
                marginTop: 15,
              }}
            >
              <Text style={{ fontWeight: "bold" }}>{title}</Text>
              <Text>{subtitle}</Text>
              <Text>{meta}</Text>
              <Text>⭐ {rating}</Text>
              <Text style={{ color: "green" }}>{price}</Text>
              <Text>{availability} slots available</Text>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}