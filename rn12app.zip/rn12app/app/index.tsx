import { router } from "expo-router"
import { Text, TouchableOpacity, View } from "react-native"

export default function Home() {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text style={{ fontSize: 20, marginBottom: 20 }}>
        Home Screen
      </Text>

      <TouchableOpacity
        onPress={() => 
          router.push("/search")   // ✅ CHANGE HERE
        }
        style={{
          backgroundColor: "#007AFF",
          padding: 15,
          borderRadius: 10,
        }}
      >
        <Text style={{ color: "white" }}>
          Do Search   {/* optional rename */}
        </Text>
      </TouchableOpacity>
    </View>
  )
}