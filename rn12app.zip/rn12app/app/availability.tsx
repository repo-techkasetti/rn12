import axios from "axios";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Calendar } from "react-native-calendars";

type AvailabilityDate = {
  date: string;
  slots: string[];
};

export default function Availability() {
  const router = useRouter();

  // ✅ Get params from search screen
  const { centerId, modalityId, testConfigId } =
    useLocalSearchParams<{
      centerId: string;
      modalityId: string;
      testConfigId: string;
    }>();

  const [availabilityData, setAvailabilityData] =
    useState<AvailabilityDate[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // const BASE_URL = "http://192.168.137.1:3000";
  //
  // const IP_ADDRESS='192.168.1.68';
  const IP_ADDRESS=process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS;
  //
  const BASE_URL = `http://${IP_ADDRESS}:3000`; // change if needed

  const getToday = () =>
    new Date().toISOString().split("T")[0];

  const fetchAvailability = async (
    startDate?: string,
    days: number = 7
  ) => {
    try {
      setLoading(true);

      const response = await axios.post(
        `${BASE_URL}/booking/availability`,
        {
          centerId,
          modalityId,
          testConfigId,
          startDate: startDate ?? getToday(),
          days,
        }
      );

      setAvailabilityData(response?.data?.dates ?? []);
    } catch (error: any) {
      console.log("API ERROR:", error?.response?.data || error.message);
      setAvailabilityData([]);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Initial load
  useEffect(() => {
    if (!centerId || !modalityId || !testConfigId) return;

    const today = getToday();
    setSelectedDate(today);
    fetchAvailability(today, 7);
  }, [centerId]);

  const markedDates = useMemo(() => {
    const marks: any = {};

    availabilityData.forEach((d) => {
      marks[d.date] = {
        marked: true,
        dotColor: "#007AFF",
      };
    });

    if (selectedDate) {
      marks[selectedDate] = {
        ...marks[selectedDate],
        selected: true,
        selectedColor: "#007AFF",
      };
    }

    return marks;
  }, [availabilityData, selectedDate]);

  const selectedSlots =
    availabilityData.find((d) => d.date === selectedDate)?.slots ?? [];

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Calendar
        markedDates={markedDates}
        onDayPress={async (day) => {
          setSelectedSlot(null);
          setSelectedDate(day.dateString);
          await fetchAvailability(day.dateString, 1);
        }}
      />

      <View style={{ marginTop: 20, flex: 1 }}>
        <Text
          style={{
            fontSize: 16,
            fontWeight: "bold",
            marginBottom: 12,
          }}
        >
          Available Slots
        </Text>

        {loading && (
          <ActivityIndicator size="large" color="#007AFF" />
        )}

        {!loading && selectedSlots.length === 0 && (
          <Text style={{ marginTop: 20, textAlign: "center" }}>
            No slots available for this date.
          </Text>
        )}

        {!loading && selectedSlots.length > 0 && (
          <FlatList
            data={selectedSlots}
            keyExtractor={(item) => item}
            numColumns={3}
            columnWrapperStyle={{
              justifyContent: "space-between",
              marginBottom: 10,
            }}
            renderItem={({ item }) => {
              const isSelected = selectedSlot === item;

              return (
                <TouchableOpacity
                  onPress={() => setSelectedSlot(item)}
                  style={{
                    flex: 1,
                    marginHorizontal: 5,
                    paddingVertical: 10,
                    borderRadius: 20,
                    backgroundColor: isSelected
                      ? "#007AFF"
                      : "#E3F2FD",
                    alignItems: "center",
                  }}
                >
                  <Text
                    style={{
                      color: isSelected
                        ? "#FFFFFF"
                        : "#007AFF",
                      fontWeight: "600",
                    }}
                  >
                    {item}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        )}
      </View>

      <TouchableOpacity
        disabled={!selectedSlot}
        onPress={() =>
          router.push({
            pathname: "/review",
            params: {
              centerId,
              modalityId,
              testConfigId,
              date: selectedDate,
              slot: selectedSlot,
            },
          })
        }
        style={{
          backgroundColor: selectedSlot
            ? "#007AFF"
            : "#B0C4DE",
          paddingVertical: 14,
          borderRadius: 30,
          alignItems: "center",
        }}
      >
        <Text
          style={{
            color: "#fff",
            fontWeight: "600",
            fontSize: 16,
          }}
        >
          Review and Proceed
        </Text>
      </TouchableOpacity>
    </View>
  );
}